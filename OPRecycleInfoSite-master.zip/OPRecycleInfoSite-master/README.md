# OPRecycleInfoSite

A basic web page made with HTML, CSS and JavaScript. Features a drag and drop game I made in JavaScript.
